import DB.DB;

public class Main {
    public static void main(String[] args) {
        DB db = new DB();
        System.out.println(db.getInfo());
    }
}
